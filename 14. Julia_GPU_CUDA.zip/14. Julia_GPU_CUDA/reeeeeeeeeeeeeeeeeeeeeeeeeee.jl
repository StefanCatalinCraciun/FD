function DiffDxplus_kernel!(dA_gpu, A_gpu, w_gpu, dx, nx, ny, l)
    x = threadIdx().x + blockDim().x * (blockIdx().x - 1)
    y = threadIdx().y + blockDim().y * (blockIdx().y - 1)

    if x <= nx && y <= ny
        if x <= l
            sum = 0.0
            for k in 1:x
                sum = sum - w_gpu[k] * A_gpu[x - (k - 1), y]
            end
            for k in 1:l
                sum = sum + w_gpu[k] * A_gpu[x + k, y]
            end
            dA_gpu[x, y] = sum / dx
        elseif x >= l+1 && x <= nx-l
            sum = 0.0
            for k in 1:l
                sum = sum + w_gpu[k] * (-A_gpu[x - (k - 1), y] + A_gpu[x + k, y])
            end
            dA_gpu[x, y] = sum / dx
        else
            sum = 0.0
            for k in 1:l
                sum = sum - w_gpu[k] * A_gpu[x - (k - 1), y]
            end
            for k in 1:(nx - x)
                sum = sum + w_gpu[k] * A_gpu[x + k, y]
            end
            dA_gpu[x, y] = sum / dx
        end
    end
    return
end


function DiffDxplus_kernel!(A_gpu, dA_gpu, w_gpu, dx, nx, ny, l)
    x = threadIdx().x + blockDim().x * (blockIdx().x - 1)
    y = threadIdx().y + blockDim().y * (blockIdx().y - 1)

    if (x >= l+1 && x <= nx-l && y <= ny)
        sum = 0.0
        sum = sum -1.2036 * A_gpu[x, y] + 1.2036 * A_gpu[x+1, y] + 0.0833 * A_gpu[x-1, y] - 0.0833 * A_gpu[x+2, y] - 0.0097 * A_gpu[x-2, y] + 0.0097 * A_gpu[x+3, y]

        dA_gpu[x, y] = sum / dx
        
    end
        
    return
end

function DiffDxplus_test(A_gpu, dA_gpu, w_gpu, dx, nx, ny, l)



    for x in (l+1):(nx - l)
        for y in 1:ny
            sum = 0.0
            sum = sum -1.2036 * A_gpu[x, y] + 1.2036 * A_gpu[x+1, y] + 0.0833 * A_gpu[x-1, y] - 0.0833 * A_gpu[x+2, y] - 0.0097 * A_gpu[x-2, y] + 0.0097 * A_gpu[x+3, y]

            dA_gpu[x, y] = sum / dx
        end
    end

end