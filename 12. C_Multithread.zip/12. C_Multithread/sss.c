  printf("OK : \n");
    printf("OK: %d\n", nx);
    printf("OK: %d\n", ny);